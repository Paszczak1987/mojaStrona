self.__precacheManifest = [
  {
    "revision": "fdfcfda2d9b1bf31db52",
    "url": "/static/js/runtime~main.fdfcfda2.js"
  },
  {
    "revision": "027f0e50cb9960ca98fa",
    "url": "/static/js/main.027f0e50.chunk.js"
  },
  {
    "revision": "227790b2be4741aac0c1",
    "url": "/static/js/2.227790b2.chunk.js"
  },
  {
    "revision": "027f0e50cb9960ca98fa",
    "url": "/static/css/main.80423020.chunk.css"
  },
  {
    "revision": "10839cc1ab9fedfaca14ede84e1de6c3",
    "url": "/index.html"
  }
];